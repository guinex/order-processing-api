package ecommerce.ecommerorderapi;


import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
class EcommerceOrderApiApplicationTests {
	void contextLoads() {
	}

}
