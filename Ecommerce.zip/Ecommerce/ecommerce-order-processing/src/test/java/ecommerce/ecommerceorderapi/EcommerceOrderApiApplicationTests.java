package ecommerce.ecommerceorderapi;

import org.junit.jupiter.api.Test;

class EcommerceOrderApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
